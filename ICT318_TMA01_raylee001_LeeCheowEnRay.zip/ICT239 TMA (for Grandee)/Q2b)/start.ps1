.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
cd .\app\




flask --debug run