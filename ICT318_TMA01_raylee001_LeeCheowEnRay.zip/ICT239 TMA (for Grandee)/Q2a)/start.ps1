.\venv\Scripts\Activate.ps1


pip install -r requirements.txt


flask --debug run